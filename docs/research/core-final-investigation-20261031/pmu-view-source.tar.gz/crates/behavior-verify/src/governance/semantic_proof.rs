//! Trusted proof generation over canonical admitted semantics. No development cache.
use super::trusted::{GovernanceSubject, R, TrustedError};
use crate::checks::{CheckResult, SemanticSite};
use crate::solver::{Query, Solver, SolverAnswer, UnknownReason};
use behavior_core::semantic::module::Module;
use serde_json::{Value as Json, json};
use std::collections::BTreeMap;

fn canonicalization_error(cause: behavior_core::canonical::CanonicalError) -> TrustedError {
    TrustedError {
        code: "CANONICALIZATION_FAILED",
        message: cause.to_string(),
    }
}

pub(super) fn subject_json(subject: &GovernanceSubject<'_>) -> R<Json> {
    Ok(match subject {
        GovernanceSubject::Module(m) => json!({"behavior_hash":m.behavior_version()}),
        GovernanceSubject::Migration(m, s, t) => {
            if !m.matches_behaviors(s, t) {
                return Err(TrustedError {
                    code: "SUBJECT_MISMATCH",
                    message: "migration behavior pair differs from resolution".into(),
                });
            }
            json!({"migration_hash":m.hash(),"source_behavior":s.behavior_version(),"target_behavior":t.behavior_version(),"source_schema":m.source_schema(),"target_schema":m.target_schema()})
        }
    })
}

fn relocate(value: &mut Json) {
    match value {
        Json::Object(o) => {
            if o.contains_key("loc") {
                o.insert("loc".into(), json!({"file":"<semantic>","line":1}));
            }
            for (k, v) in o {
                if k != "loc" {
                    relocate(v);
                }
            }
        }
        Json::Array(a) => {
            for v in a {
                relocate(v);
            }
        }
        _ => {}
    }
}
fn expression(value: &mut Json, env: &BTreeMap<String, String>, depth: u32) {
    let Some(o) = value.as_object_mut() else {
        return;
    };
    let op = o
        .get("op")
        .and_then(Json::as_str)
        .unwrap_or_default()
        .to_string();
    if ["field", "param"].contains(&op.as_str()) {
        for key in ["param", "name"] {
            if let Some(v) = o.get_mut(key)
                && let Some(n) = v.as_str().and_then(|n| env.get(n))
            {
                *v = json!(n);
            }
        }
    }
    if op == "derived"
        && let Some(a) = o.get_mut("args").and_then(Json::as_array_mut)
    {
        for v in a {
            if let Some(n) = v.as_str().and_then(|n| env.get(n)) {
                *v = json!(n);
            }
        }
    }
    // Query/fold binders introduce lexical scope only in their body. Base query
    // and captures continue to use the enclosing scope.
    let mut inner = env.clone();
    if !["field", "param"].contains(&op.as_str())
        && let Some(old) = o.get("param").and_then(Json::as_str).map(str::to_string)
    {
        let name = format!("q{depth}");
        inner.insert(old, name.clone());
        o.insert("param".into(), json!(name));
    }
    for (key, v) in o.iter_mut() {
        if key == "body" {
            expression(v, &inner, depth.saturating_add(1));
        } else if key == "args" && op != "derived" {
            if let Some(a) = v.as_array_mut() {
                for x in a {
                    expression(x, env, depth.saturating_add(1));
                }
            }
        } else if key == "arg" {
            expression(v, env, depth.saturating_add(1));
        }
    }
}

pub(super) fn canonical_module(module: &Module) -> R<Module> {
    let mut wire = behavior_core::serialize::to_wire_value(module);
    relocate(&mut wire);
    for section in ["derived", "actions", "reads"] {
        if let Some(items) = wire.get_mut(section).and_then(Json::as_array_mut) {
            for item in items {
                let mut env = BTreeMap::new();
                if let Some(params) = item["params"].as_array_mut() {
                    for p in params.iter_mut() {
                        if let Some(old) = p["name"].as_str().map(str::to_string) {
                            // Legacy capability parameter names are public binding keys
                            // and participate in identity. They are not alpha aliases.
                            env.insert(old.clone(), old);
                        }
                    }
                }
                if section == "actions" {
                    if let Some(commands) =
                        item.get_mut("command_effects").and_then(Json::as_array_mut)
                    {
                        for command in commands {
                            expression(&mut command["when"], &env, 0);
                            if let Some(payload) = command["payload"].as_object_mut() {
                                for value in payload.values_mut() {
                                    expression(value, &env, 0);
                                }
                            }
                        }
                    }
                    for key in ["preconditions", "postconditions"] {
                        if let Some(a) = item[key].as_array_mut() {
                            for c in a {
                                expression(&mut c["expr"], &env, 0);
                            }
                        }
                    }
                    if let Some(a) = item["effects"].as_array_mut() {
                        for effect in a {
                            for key in ["param", "remove"] {
                                if let Some(v) = effect.get_mut(key)
                                    && let Some(n) = v.as_str().and_then(|n| env.get(n))
                                {
                                    *v = json!(n);
                                }
                            }
                            if let Some(v) =
                                effect.get_mut("target").and_then(|v| v.get_mut("param"))
                                && let Some(n) = v.as_str().and_then(|n| env.get(n))
                            {
                                *v = json!(n);
                            }
                            for key in ["value", "id"] {
                                if let Some(v) = effect.get_mut(key) {
                                    expression(v, &env, 0);
                                }
                            }
                            if let Some(fields) =
                                effect.get_mut("fields").and_then(Json::as_object_mut)
                            {
                                for v in fields.values_mut() {
                                    expression(v, &env, 0);
                                }
                            }
                        }
                    }
                } else if section == "reads" {
                    if let Some(v) = item["body"].get_mut("value") {
                        expression(v, &env, 0);
                    }
                    if let Some(p) = item["body"].get_mut("project") {
                        if let Some(over) = p.get_mut("over") {
                            if let Some(name) = over.as_str().and_then(|n| env.get(n)) {
                                *over = json!(name);
                            } else {
                                expression(over, &env, 0);
                            }
                        }
                        if let Some(v) = p.get_mut("param") {
                            *v = json!(
                                v.as_str()
                                    .and_then(|n| env.get(n))
                                    .cloned()
                                    .unwrap_or_else(|| "q0".into())
                            );
                        }
                    }
                } else {
                    expression(&mut item["body"], &env, 0);
                }
            }
        }
    }
    for section in ["constraints", "invariants"] {
        if let Some(items) = wire.get_mut(section).and_then(Json::as_array_mut) {
            for item in items {
                let mut env = BTreeMap::new();
                if let Some(old) = item["param"].as_str().map(str::to_string) {
                    env.insert(old.clone(), old);
                }
                expression(&mut item["body"], &env, 0);
            }
        }
    }
    let normalized = behavior_core::admit(&wire.to_string()).map_err(|e| TrustedError {
        code: "SEMANTIC_NORMALIZATION",
        message: format!(
            "canonical admitted serialization failed re-admission: {:?}",
            e.errors
        ),
    })?;
    if normalized.behavior_version() != module.behavior_version() {
        return Err(TrustedError {
            code: "SEMANTIC_NORMALIZATION",
            message: "normalization changed semantic identity".into(),
        });
    }
    Ok(normalized)
}

pub(super) fn checks(
    subject: &GovernanceSubject<'_>,
    profile: &crate::Profile,
    solver: &dyn Solver,
) -> R<Vec<CheckResult>> {
    match subject {
        GovernanceSubject::Module(m) => {
            let m = canonical_module(m)?;
            let mut report =
                crate::verify_complete(&m, profile, solver).map_err(canonicalization_error)?;
            validate_reference_inventory(&m, profile, &report.checks)?;
            for c in &mut report.checks {
                if c.site.is_none() {
                    // Declaration-level rule checks have a canonical public-map
                    // address; caller display names never supply binder identity.
                    let owner = c.subject.hash.clone();
                    c.site = Some(SemanticSite {
                        owner_hash: owner,
                        phase: "declaration",
                        semantic_path: vec![json!({"field":c.subject.name})],
                        predicate_kind: c.check.into(),
                    });
                }
            }
            Ok(report.checks)
        }
        GovernanceSubject::Migration(m, s, t) => {
            subject_json(subject)?;
            let s = canonical_module(s)?;
            let t = canonical_module(t)?;
            let migration =
                behavior_core::migration::admit_migration(&s, &t, &m.resolved().to_string())
                    .map_err(|_| TrustedError {
                        code: "SUBJECT_MISMATCH",
                        message: "canonical migration failed re-admission".into(),
                    })?;
            if migration.hash() != m.hash() {
                return Err(TrustedError {
                    code: "SUBJECT_MISMATCH",
                    message: "canonical migration changed identity".into(),
                });
            }
            let mut report = crate::verify_migration(&migration, &s, &t, profile, None, solver);
            report.checks.extend(crate::migration::requirement_checks(
                &migration, &s, profile, solver,
            ));
            if report.checks.iter().any(|c| c.site.is_none()) {
                return Err(TrustedError {
                    code: "INCOMPLETE_VERIFICATION",
                    message: "migration check lacks a semantic syntax address".into(),
                });
            }
            Ok(report.checks)
        }
    }
}

fn validate_reference_inventory(
    module: &Module,
    profile: &crate::Profile,
    checks: &[CheckResult],
) -> R<()> {
    use behavior_core::semantic::{
        module::ParamRole,
        types::{Type, hash_display},
    };
    let fail = || TrustedError {
        code: "INCOMPLETE_VERIFICATION",
        message: "reference-world inventory differs from admitted semantics".into(),
    };
    if !profile.checks.contains(&crate::CheckKind::Preservation) {
        return if checks.iter().any(|c| c.subject.kind == "reference_world") {
            Err(fail())
        } else {
            Ok(())
        };
    }
    let mut accounted = 0;
    for (name, action) in module.actions() {
        let hash = hash_display(action.hash());
        let selected: Vec<_> = checks
            .iter()
            .filter(|c| {
                c.kind == crate::CheckKind::Preservation
                    && c.action
                        .as_ref()
                        .is_some_and(|(n, h)| n == name && h == &hash)
            })
            .collect();
        if selected.iter().any(|c| {
            matches!(c.outcome, crate::checks::Outcome::Inconclusive(_))
                && c.site
                    .as_ref()
                    .is_some_and(|s| s.predicate_kind == "representation_safety")
        }) {
            // A conservative encoding refusal has no fresh theorem authority.
            continue;
        }
        let mut removed = std::collections::BTreeSet::new();
        let removed_params: std::collections::BTreeSet<_> =
            action.removes().iter().map(|r| r.param()).collect();
        for p in action.params() {
            if removed_params.contains(p.name())
                && let Type::Entity(t) = p.ty()
            {
                removed.insert(t.as_str());
            }
        }
        let needs = removed.iter().any(|t| !module.references_to(t).is_empty());
        let actual: Vec<_> = selected
            .iter()
            .filter(|c| c.subject.kind == "reference_world")
            .collect();
        let mut required = 0;
        if needs {
            // Deliberately independent of Encoder::reference_checks and its
            // inventory helper. Inspect every admitted declaration and effect.
            for (source, entity) in module.entities() {
                let changed = action.params().iter().any(|p| {
                    p.role() == ParamRole::State
                        && !removed_params.contains(p.name())
                        && p.ty() == &Type::Entity(source.clone())
                }) || action.creates().iter().any(|c| c.entity() == source);
                for (field, target) in entity.reference_fields() {
                    if !changed && !removed.contains(target) {
                        continue;
                    }
                    required += 1;
                    let (_, constraint) = module
                        .constraints_for(source)
                        .find(|(_, c)| c.reference() == Some(field))
                        .ok_or_else(fail)?;
                    let path = vec![
                        json!({"field":name}),
                        json!({"field":"reference_world"}),
                        json!({"field":source}),
                        json!({"field":field}),
                    ];
                    let matching = actual
                        .iter()
                        .filter(|c| {
                            c.subject.param.is_none()
                                && c.subject.hash == hash_display(constraint.hash())
                                && c.site.as_ref().is_some_and(|s| {
                                    s.owner_hash == hash
                                        && s.phase == "final_invariant"
                                        && s.predicate_kind == "reference_preservation"
                                        && s.semantic_path == path
                                })
                        })
                        .count();
                    if matching != 1 {
                        return Err(fail());
                    }
                }
            }
        }
        if actual.len() != required {
            return Err(fail());
        }
        accounted += actual.len();
    }
    if checks
        .iter()
        .filter(|c| c.subject.kind == "reference_world")
        .count()
        != accounted
    {
        return Err(fail());
    }
    Ok(())
}

/// Drives only the fixed encoding/site generator. No theorem result from this
/// planning pass is usable as evidence, and it performs no solver process I/O.
pub(super) struct SitePlanner<'a>(pub &'a str);
impl Solver for SitePlanner<'_> {
    fn version(&self) -> String {
        self.0.into()
    }
    fn check(&self, _: &Query) -> SolverAnswer {
        SolverAnswer::Unknown(UnknownReason::ResourceLimit)
    }
}

#[cfg(test)]
#[allow(clippy::unwrap_used, clippy::expect_used)]
mod canonicalization_tests {
    #[test]
    fn omitted_reference_site_is_rejected_independently_of_the_report() {
        let module = behavior_core::admit(include_str!(concat!(
            env!("CARGO_MANIFEST_DIR"),
            "/../../tests/fixtures/verify/ref-removals/guarded.json"
        )))
        .unwrap();
        let profile = crate::Profile {
            checks: vec![crate::CheckKind::Preservation],
            ..crate::Profile::default()
        };
        let mut report =
            crate::verify_complete(&module, &profile, &super::SitePlanner("z3 4.16.0")).unwrap();
        let mut extra = report
            .checks
            .iter()
            .find(|c| c.subject.kind == "reference_world")
            .unwrap()
            .clone();
        extra.action = Some((
            "unknown_action".into(),
            format!("sha256:{}", "ab".repeat(32)),
        ));
        let mut extra_checks = report.checks.clone();
        extra_checks.push(extra);
        assert!(
            super::validate_reference_inventory(&module, &profile, &extra_checks).is_err(),
            "unknown reference scope was ignored"
        );
        report
            .checks
            .retain(|c| c.subject.kind != "reference_world");
        assert!(super::validate_reference_inventory(&module, &profile, &report.checks).is_err());
    }
    #[test]
    fn canonicalization_bridge_preserves_category_and_cause() {
        use behavior_core::canonical::CanonicalError;
        for cause in [
            CanonicalError::Float("$.findings[0].items[0]".into()),
            CanonicalError::Serialize("encoding failed".into()),
        ] {
            let expected = cause.to_string();
            let mapped = super::canonicalization_error(cause);
            assert_eq!(mapped.code, "CANONICALIZATION_FAILED");
            assert_eq!(mapped.message, expected);
        }
    }
}
