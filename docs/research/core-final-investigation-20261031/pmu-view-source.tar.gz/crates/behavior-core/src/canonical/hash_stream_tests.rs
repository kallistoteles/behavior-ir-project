#![allow(clippy::unwrap_used)]
use super::*;
use serde_json::json;
use std::cell::Cell;

thread_local! { static TEXT_BYTES: Cell<usize> = const { Cell::new(0) }; }
pub(super) fn note_text(bytes: usize) {
    TEXT_BYTES.with(|counter| counter.set(counter.get() + bytes));
}

fn reference(tag: &str, doc: &Value) -> Result<String, CanonicalError> {
    use sha2::{Digest, Sha256};
    // Frozen former control flow, retaining complete-value error precedence.
    let text = if doc.get("hash").is_some() {
        check_canonical_value(doc)?;
        let mut value = doc.clone();
        if let Value::Object(object) = &mut value {
            object.remove("hash");
        }
        to_canonical_string(&value)?
    } else {
        to_canonical_string(doc)?
    };
    let mut digest = Sha256::new();
    digest.update(tag.as_bytes());
    digest.update([0]);
    digest.update(text.as_bytes());
    Ok(format!("sha256:{:x}", digest.finalize()))
}

#[test]
fn tagged_hash_does_not_materialize_a_canonical_output_string() {
    let document = json!({"a": ["x".repeat(65536)], "hash": "excluded", "nested": {"hash": 7}});
    let expected = reference("resource-goal", &document).unwrap();
    TEXT_BYTES.with(|counter| counter.set(0));
    assert_eq!(tagged_hash("resource-goal", &document).unwrap(), expected);
    assert_eq!(
        TEXT_BYTES.with(Cell::get),
        0,
        "hash should stream canonical bytes"
    );
}

#[test]
fn full_value_errors_precede_top_level_hash_exclusion() {
    for (document, path) in [
        (json!({"hash": [0.5], "z": 1}), "$.hash[0]"),
        (json!({"a": {"x": 0.5}, "hash": 0.25}), "$.a.x"),
        (json!([{"hash": 0.5}]), "$[0].hash"),
        (json!(0.5), "$"),
    ] {
        assert_eq!(
            tagged_hash("errors", &document),
            Err(CanonicalError::Float(path.into()))
        );
        assert_eq!(
            tagged_hash("errors", &document),
            reference("errors", &document)
        );
    }
}

#[test]
fn canonical_string_contract_remains_compact_ordered_utf8() {
    let value =
        json!({"z": [null, true, "é\n\""], "a": -7, "hash": "kept for ordinary serialization"});
    assert_eq!(
        to_canonical_string(&value).unwrap(),
        "{\"a\":-7,\"hash\":\"kept for ordinary serialization\",\"z\":[null,true,\"é\\n\\\"\"]}"
    );
}

#[test]
fn scalar_nested_and_large_documents_match_frozen_hashing() {
    let mut documents = vec![
        Value::Null,
        json!(true),
        json!(false),
        json!(i64::MIN),
        json!(i64::MAX),
        json!(u64::MAX),
        json!("quote\"slash\\tab\t零"),
        json!([]),
        json!({}),
        json!({"hash": null}),
        json!({"nested": {"hash": 7}, "array": [{"hash": 9}]}),
    ];
    for seed in 0..256 {
        documents.push(
            json!({"z":seed,"hash":{"excluded":seed},"a":[seed, -seed, "é".repeat(seed as usize)],
                              "nested":{"hash":seed, "value": format!("\u{0}{seed}\n")}}),
        );
    }
    for document in documents {
        for tag in ["", "behavior.transition.v1", "tag\0suffix"] {
            assert_eq!(tagged_hash(tag, &document), reference(tag, &document));
        }
    }
}

#[test]
fn composed_view_matches_materialized_objects_and_exact_float_paths() {
    use std::collections::BTreeMap;
    let record = json!({"trace":[{"hash":"bound","n":7}],"str":"é\n"});
    let view = DocumentView::Object(BTreeMap::from([
        ("z", DocumentView::Owned(json!(u64::MAX))),
        (
            "bundle",
            DocumentView::Object(BTreeMap::from([
                ("record", DocumentView::Borrowed(&record)),
                ("hash", DocumentView::Owned(json!("nested stays"))),
            ])),
        ),
        ("hash", DocumentView::Owned(json!("root excluded"))),
    ]));
    let materialized = serde_json::to_value(&view).unwrap();
    assert_eq!(
        tagged_hash_view("view", &view),
        reference("view", &materialized)
    );
    let bad = json!({"hash":[0.5]});
    let bad_view = DocumentView::Object(BTreeMap::from([
        ("bundle", DocumentView::Borrowed(&bad)),
        ("hash", DocumentView::Owned(json!(0.25))),
    ]));
    assert_eq!(
        tagged_hash_view("view", &bad_view),
        Err(CanonicalError::Float("$.bundle.hash[0]".into()))
    );
    let root_only = DocumentView::Object(BTreeMap::from([("hash", DocumentView::Borrowed(&bad))]));
    assert_eq!(
        tagged_hash_view("view", &root_only),
        Err(CanonicalError::Float("$.hash.hash[0]".into()))
    );
}

#[test]
fn composed_view_hash_does_not_materialize_canonical_text() {
    use std::collections::BTreeMap;
    let record = json!(["x".repeat(65536)]);
    let view = DocumentView::Object(BTreeMap::from([(
        "record",
        DocumentView::Borrowed(&record),
    )]));
    let expected = reference("view-resource", &serde_json::to_value(&view).unwrap()).unwrap();
    TEXT_BYTES.with(|counter| counter.set(0));
    assert_eq!(tagged_hash_view("view-resource", &view).unwrap(), expected);
    assert_eq!(
        TEXT_BYTES.with(Cell::get),
        0,
        "view hash should stream canonical bytes"
    );
}

#[test]
fn owned_root_views_match_borrowed_roots_and_keep_nested_hashes() {
    for document in [
        json!({"hash":1,"n":{"hash":2}}),
        json!([{"hash":3}]),
        json!("é"),
        json!({"hash":null}),
    ] {
        let expected = reference("owned", &document);
        assert_eq!(
            tagged_hash_view("owned", &DocumentView::Owned(document)),
            expected
        );
    }
}
