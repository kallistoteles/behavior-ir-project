#![allow(clippy::unwrap_used, dead_code)]
use super::*;
pub(super) trait FrozenHash {
    fn frozen_hash(&self) -> R<String>;
}
impl CommitBundle {
    fn frozen_governance_candidate(
        &self,
    ) -> R<behavior_verify::governance::trusted::GovernanceCandidate> {
        if self.format != TAG_COMMIT_BUNDLE_V2 {
            return Err(StoreError::Contract {
                code: "HISTORY_FORMAT_UPGRADE_REQUIRED",
                message: "candidate requires a v2 bundle with an exact history head".into(),
            });
        }
        let history = self
            .evaluated_history
            .as_ref()
            .ok_or_else(|| StoreError::BundleInvalid("missing evaluated_history".into()))?;
        history.validate()?;
        if history.state_ref() != self.evaluated_state || history.store != self.store {
            return Err(StoreError::BundleInvalid(
                "history/state/store basis differs".into(),
            ));
        }
        let content = serde_json::json!({"kind":"action","store":self.store,"evaluated_history":history,"behavior_version":self.behavior_version,"record":self.record,
            "entity_declarations":self.entity_declarations,"read_set":self.read_set,"read_facts":if self.read_facts.is_null(){serde_json::json!({})}else{self.read_facts.clone()},"write_set":self.write_set,"write_lifecycle":self.write_lifecycle});
        let transition = hash_of(
            behavior_verify::hashing::TAG_CANDIDATE_TRANSITION_V2,
            &content,
        )?;
        behavior_verify::governance::trusted::GovernanceCandidate::from_json(&serde_json::json!({"format":"behavior.governance_candidate.v2","content":content,"transition_hash":transition}).to_string())
            .map_err(|e|StoreError::BundleInvalid(e.to_string()))
    }
}
impl FrozenHash for CommitBundle {
    fn frozen_hash(&self) -> R<String> {
        match self.format.as_str() {
            TAG_COMMIT_BUNDLE => {
                if self.evaluated_history.is_some()
                    || self.authorization_context.is_some()
                    || self
                        .evidence
                        .as_ref()
                        .is_some_and(|e| e.as_trusted().is_some())
                {
                    return Err(StoreError::BundleInvalid(
                        "legacy bundle contains v2 semantics".into(),
                    ));
                }
                hash_of(TAG_COMMIT_BUNDLE, self)
            }
            TAG_COMMIT_BUNDLE_V2 => {
                if self.frozen_governance_candidate()?.hash() != self.transition_hash {
                    return Err(StoreError::BundleInvalid(
                        "v2 candidate identity differs".into(),
                    ));
                }
                if self
                    .evidence
                    .as_ref()
                    .is_some_and(|e| e.as_legacy().is_some())
                {
                    return Err(StoreError::BundleInvalid(
                        "v2 bundle cannot contain structural legacy evidence".into(),
                    ));
                }
                hash_of(TAG_COMMIT_BUNDLE_V2, self)
            }
            _ => Err(StoreError::BundleInvalid(
                "unknown commit bundle format".into(),
            )),
        }
    }
}
impl TransitionRecord {
    fn frozen_check_kind(&self) -> R<()> {
        let valid = match (
            self.format.as_str(),
            self.kind.as_deref(),
            &self.bundle,
            &self.migration,
        ) {
            (TAG_TRANSITION_RECORD, None, Some(b), None) => b.format == TAG_COMMIT_BUNDLE,
            (TAG_TRANSITION_RECORD, Some(KIND_MIGRATION), None, Some(m)) => m.format.is_none(),
            (TAG_TRANSITION_RECORD_V2, Some("action"), Some(b), None) => {
                b.frozen_hash()?;
                let h = b
                    .evaluated_history
                    .as_ref()
                    .ok_or_else(|| StoreError::BundleInvalid("missing evaluated history".into()))?;
                h.state_ref() == self.evaluated_against && h.record == self.previous_record
            }
            (TAG_TRANSITION_RECORD_V2, Some(KIND_MIGRATION), None, Some(m)) => {
                m.hash()?;
                let h = HistoryRef::from_json(
                    &m.candidate.as_ref().ok_or_else(|| {
                        StoreError::BundleInvalid("missing migration candidate".into())
                    })?["content"]["evaluated_history"]
                        .to_string(),
                )?;
                h.state_ref() == self.evaluated_against && h.record == self.previous_record
            }
            _ => false,
        };
        if !valid {
            return Err(StoreError::BundleInvalid(
                "event kind/format/history product differs".into(),
            ));
        }
        if self.format == TAG_TRANSITION_RECORD_V2
            && (self.evaluated_against != self.committed_on
                || self.committed_on.position.checked_add(1) != Some(self.position)
                || self.result_state.position != self.position)
        {
            return Err(StoreError::BundleInvalid(
                "v2 event position/history basis differs".into(),
            ));
        }
        Ok(())
    }
}
impl FrozenHash for TransitionRecord {
    fn frozen_hash(&self) -> R<String> {
        self.frozen_check_kind()?;
        match self.format.as_str() {
            TAG_TRANSITION_RECORD => hash_of(TAG_TRANSITION_RECORD, self),
            TAG_TRANSITION_RECORD_V2 => hash_of(TAG_TRANSITION_RECORD_V2, self),
            _ => Err(StoreError::BundleInvalid(
                "unknown transition format".into(),
            )),
        }
    }
}
